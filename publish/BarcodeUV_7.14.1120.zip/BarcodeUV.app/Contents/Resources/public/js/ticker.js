

var app = {
    optionsViewModel:null,
    barcodeObj:null,
    barcodeOptions:null,

    systemFontList:[],
    outputFilePath: "",
    outputFileSize: 0, //file size byte


    errMsg:"'save error! please send email to app.romanysoft@gmail.com!'",
    successMsg:"save success!",

    launch: function () {
        this.initViewModel();
        this.initUI();
    },

    initViewModel:function(){
        app.barcodeOptions = {
            renderAs:"canvas",
            background:"#ffffff",
            color:"#05933e",
            checksum:false,
            height:100,
            width:300,
            padding:{
                top:0,
                left:0,
                right:0,
                bottom:0
            },
            border:{
                color:"#b3b2a9",
                dashType:"solid",
                width:2
            },
            text:{
                color:"#030303",
                font:"Consolas, Monaco, Sans Mono, monospace, sans-serif",
                size:16,
                margin:{
                    top:0,
                    left:0,
                    right:0,
                    bottom:0
                },
                visible:true
            },
            type:"EAN8",
            value:"1234567"
        };

        this.optionsViewModel = kendo.observable({
            barOptions:app.barcodeOptions
        });

        this.optionsViewModel.bind("change", function(e){
            app.barcodeOptions = this.barOptions.toJSON();
            app._setOptions();
        });

        kendo.bind($("#barcodeConfig"), this.optionsViewModel);

    },

    initUI: function () {
        this._importFontList();
        this._initOptionsUI();
        this._initSaveConfigUI();
        this._initPreviewUI();
        this._initRevealInFinderBtnUI();
    },

    _initOptionsUI:function(){
        $('#encoding').kendoDropDownList({
            dataSource: [
                { type: 'EAN8', value: "1234567" },
                { type: 'EAN13', value: "123456789987" },
                { type: 'UPCE', value: "123456" },
                { type: 'UPCA', value: "12345678998" },
                { type: 'Code11', value: "1234567" },
                { type: 'Code39', value: "HELLO" },
                { type: 'Code39Extended', value: "Hi!" },
                { type: 'Code93', value: "HELLO" },
                { type: 'Code93Extended', value: "Hello" },
                { type: 'Code128', value: "Hello World!" },
                { type: 'Code128A', value: "HELLO" },
                { type: 'Code128B', value: "Hello" },
                { type: 'Code128C', value: "123456" },
                { type: 'MSImod10', value: "1234567" },
                { type: 'MSImod11', value: "1234567" },
                { type: 'MSImod1010', value: "1234567" },
                { type: 'MSImod1110', value: "1234567" },
                { type: 'GS1-128', value: "12123456" },
                { type: 'POSTNET', value: "12345" }
            ],
            change: app._setOptions,
            dataTextField: "type",
            dataValueField: "type"
        });
        $('#renderAs').kendoDropDownList({
            dataSource:[
                { type: 'Canvas', value: "canvas" },
                { type: 'SVG', value: "svg" },
                { type: 'VML', value: "vml" }
            ],
            change: app._setOptions,
            dataTextField: "type",
            dataValueField: "value"
        });
        $('#dashType').kendoDropDownList({
            dataSource:[
                { type: 'solid', value: "solid" },
                { type: 'dotted', value: "dotted" },
                { type: 'dashed', value: "dashed" },
                { type: 'double', value: "double" },
                { type: 'groove', value: "groove" },
                { type: 'ridge', value: "ridge" },
                { type: 'inset', value: "inset" },
                { type: 'outset', value: "outset" },
                { type: 'outset', value: "outset" },
                { type: 'dotted solid', value: "dotted solid" },
                { type: 'dotted solid double dashed', value: "dotted solid double dashed" }
            ],
            change: app._setOptions,
            dataTextField: "type",
            dataValueField: "value"
        });


        var fontList = [];
        for(var i=0; i < app.systemFontList.length; ++i){
            var e = app.systemFontList[i];
            var fontObj = {"type": e.type, "value": e.value};
            fontList.push(fontObj);
        }
        $('#textFont').kendoDropDownList({
            dataSource:fontList,
            change: app._setOptions,
            dataTextField: "type",
            dataValueField: "value"
        });



        // Data change to process
        $('#barcodeValue,#s-checksum,#s-text,#s-border,#s-background').change(app._setOptions);

    },

    _initSaveConfigUI:function(){
        $('#export_type').kendoDropDownList({
            dataSource: [
                { type: 'PNG File', value: "png" },
                { type: 'JPG File', value: "jpg" },
                { type: 'JPEG 2000 File', value: "jpeg" },
                { type: 'TIFF File', value: "tif" },
                { type: 'GIF File', value: "gif" },
                { type: 'PDF File', value: "pdf" },
                { type: 'EPS File', value: "eps" },
                { type: 'SVG File', value: "svg" }

            ],
            dataTextField: "type",
            dataValueField: "value"
        });


        // export Btn
        $('#exportBtn').kendoButton({});
        $("#exportBtn").on('click',function(){
            var saveType = $('#export_type').val() || 'jpg'; // default save img type
            var dataUrlStr = $('#barcode canvas')[0].toDataURL('image/jpg');

            var params = {
                callback: 'window.handSaveFileFuc',
                types:[saveType]
            };
            var paramStr = JSON.stringify(params);
            window['handSaveFileFuc'] = function(obj){
                if (obj.success){
                    //get the path, then save
                    app.outputFilePath = obj.filePath;

                    var params = {
                        "callback":'window.handBase64ToImageFileFunc',
                        "imageType":$('#export_type').val() || 'jpg',
                        "filePath":obj.filePath,
                        "base64String":dataUrlStr.split(',')[1] // 去除data:imgaes/jpg;base64,字符串
                    };

                    if (saveType == 'svg') {
                        params['text'] = $("#barcode").data("kendoBarcode").svg();
                        params['base64String'] = '';
                    } 
                    var paramStr = JSON.stringify(params);
                    window['handBase64ToImageFileFunc'] = function(obj){
                        if (obj.success){
                            //get the result
                            var result = obj.result;
                            alert(app.successMsg);
                        }else {

                            try{
                                var params = {
                                    "path":app.outputFilePath
                                };
                                var paramStr = JSON.stringify(params);
                                (typeof macgap) && (macgap.window.removeFile(paramStr));
                            }catch(e){console.log(e)}
                            //Error
                            alert(app.errMsg);
                        }
                    };

                    // 启动处理
                    try{
                         var binaryFileFunc = "base64ToImageFile";
                         if (saveType == 'svg') binaryFileFunc = "writeTextToFile";
                         
                        (typeof macgap) && (macgap.binaryFileWriter[binaryFileFunc](paramStr));
                    }catch(e){console.log(e)}

                }

            };

            try{
                (typeof macgap) && (macgap.window.saveFile(paramStr));
            }catch(e){console.error(e)}
        });
    },

    _initPreviewUI:function(){
        var borderWidth = 0;
        if ($('#s-border').is(':checked'))borderWidth = app.barcodeOptions.border.width;

        var backgroundColor = app.barcodeOptions.background;
        if ($('#s-background').is(':checked')) backgroundColor = "transparent";

        app.barcodeObj = $("#barcode").kendoBarcode({
            background: backgroundColor,
            renderAs:"canvas",
            color:app.barcodeOptions.color,
            height:app.barcodeOptions.height,
            width:app.barcodeOptions.width,
            checksum: $('#s-checksum').is(':checked'),
            padding:{
                top:app.barcodeOptions.padding.top,
                left:app.barcodeOptions.padding.left,
                right:app.barcodeOptions.padding.right,
                bottom:app.barcodeOptions.padding.bottom
            },
            border:{
                color:app.barcodeOptions.border.color,
                dashType:app.barcodeOptions.border.dashType,
                width:borderWidth
            },
            text:{
                color:app.barcodeOptions.text.color,
                font: app.barcodeOptions.text.size + " " + app.barcodeOptions.text.font,
                margin:{
                    top:app.barcodeOptions.text.margin.top,
                    left:app.barcodeOptions.text.margin.left,
                    right:app.barcodeOptions.text.margin.right,
                    bottom:app.barcodeOptions.text.margin.bottom
                },
                visible: $('#s-text').is(':checked')
            },

            value: "1234567",
            type: "ean8"
        });

        app._optBarcodePos();
    },

    _initRevealInFinderBtnUI:function(){
        $('#revealInFinderBtn').kendoButton({});
        $('#revealInFinderBtn').on('click',function(){
            if (app.outputFilePath.length < 1) return;
            // reveal in finder
            app._revealInFinder(app.outputFilePath);
        });
    },

    _setOptions:function(e){
        var validValue = $('#validValue');
        var validValueLi = $('#validValueLi');

        var borderWidth = 0;
        if ($('#s-border').is(':checked'))borderWidth = app.barcodeOptions.border.width;

        var backgroundColor = app.barcodeOptions.background;
        if ($('#s-background').is(':checked')) backgroundColor = "transparent";

        if (this.element && this.element[0].id == "type") {
            $('#barcodeValue').val(this.dataItem().value);
        }
        try {
            var barcode = $('#barcode').data('kendoBarcode');
            barcode.setOptions({
                renderAs:$('#readerAs').kendoDropDownList('value'),
                background:backgroundColor,
                checksum: $('#s-checksum').is(':checked'),
                color:app.barcodeOptions.color,
                height:app.barcodeOptions.height,
                width:app.barcodeOptions.width,
                padding:{
                    top:app.barcodeOptions.padding.top,
                    left:app.barcodeOptions.padding.left,
                    right:app.barcodeOptions.padding.right,
                    bottom:app.barcodeOptions.padding.bottom
                },
                border:{
                    color:app.barcodeOptions.border.color,
                    dashType:app.barcodeOptions.border.dashType,
                    width:borderWidth
                },
                text:{
                    color:app.barcodeOptions.text.color,
                    font: app.barcodeOptions.text.size + " " + $('#textFont').kendoDropDownList('value'),
                    margin:{
                        top:app.barcodeOptions.text.margin.top,
                        left:app.barcodeOptions.text.margin.left,
                        right:app.barcodeOptions.text.margin.right,
                        bottom:app.barcodeOptions.text.margin.bottom
                    },
                    visible: $('#s-text').is(':checked')
                },

                value:$('#barcodeValue').val(),
                type: $('#encoding').kendoDropDownList('value')

            });

            barcode.redraw();

            app._optBarcodePos();

            // valid
            validValueLi.hide();
            validValue.hide();
        } catch (e) {
            validValueLi.show();
            validValue.text(e.message).show();
        }
    },

    _optBarcodePos:function(){
        var canvasWidth = $('#barcode canvas').width();
        var barcodeDivWidth = $('#barcode').width();

        var marginLeft = (barcodeDivWidth - canvasWidth)/2;
        $('#barcode canvas').css({'margin-left':marginLeft + "px" });
    },

    _importFontList:function(){
        app.systemFontList = [{type:"default font",value:app.barcodeOptions.text.font}]


        try {
            if (typeof macgap){
                var _systemFontNames = macgap.window.availableFonts();
                for(var i = 0; i < _systemFontNames.length; ++i){
                    var _fontName = _systemFontNames[i];
                    var fontObj = {type:_fontName, value:_fontName};
                    app.systemFontList.push(fontObj);
                }
            }

        } catch (e) {
            console.error(e)
        }
    },

    _revealInFinder:function(filePath){
        var params = {filePath: filePath};
        var paramStr = JSON.stringify(params);
        try {
            (typeof macgap) && (macgap.window.revealInFinder(paramStr));
        } catch (e) {
            console.error(e)
        }
    }
};


